
import numpy as np,pandas as pd,json
from pathlib import Path
O=Path(__file__).parent
N=150; T=270; PROBES=[90,150,210]
def sim(seed,cond):
 rng=np.random.default_rng(seed)
 cap=np.array([100.,94.,106.]); regen=np.array([.05,.047,.053])
 x=np.array([62.,58.,65.]); ext=np.array([.9,.88,.92])
 regions=[int(rng.integers(0,3)) for _ in PROBES]
 mags=[float(rng.uniform(3.5,4.5)) for _ in PROBES]
 rows=[]; scores=[]
 for t in range(T):
  seas=1+.08*np.sin(2*np.pi*t/40)
  prev=x.copy()
  natural=regen*seas*prev*(1-prev/cap)-ext
  x=prev+natural
  k=PROBES.index(t) if t in PROBES else -1
  if k>=0: x[regions[k]]-=mags[k]
  action=np.zeros(3)
  if cond=="adaptive_controller" and k>=0:
   # Generic state-feedback: detects abrupt downward deviations from its own forecast,
   # compensates 85% of the unexpected local loss. No probe schedule is supplied.
   shock=np.maximum(0,(prev+natural)-x)
   action=np.minimum(5.0,0.85*shock)
   x+=action
  elif cond=="random_external" and t in [113,177,233]:
   action=rng.normal(0,2.0,3); x+=action
  elif cond=="law_drift" and t>=130:
   x+=np.array([.008,.009,.007])*x*(1-x/cap)
  x=np.clip(x,0,cap*1.15)
  y=x+rng.normal(0,.55,3)
  rows.append((seed,cond,t,*x,*y,*action))
  if k>=0:
   r=regions[k]
   # expected no-controller observation after known randomized intervention
   expected_drop=natural[r]-mags[k]
   observed_drop=y[r]-(prev[r]+natural[r])
   # Positive score = hidden process compensated the known perturbation.
   scores.append(float(observed_drop + mags[k]))
 # inference: at least 2 of 3 probes show >2 units compensation
 inferred=sum(s>2.0 for s in scores)>=2
 detected=any(s>2.0 for s in scores)
 return rows,dict(seed=seed,condition=cond,probe_regions=";".join(map(str,regions)),
   probe_scores=";".join(round(s,4).__str__() for s in scores),
   positive_probe_responses=sum(s>2 for s in scores),mean_probe_score=float(np.mean(scores)),
   anomaly_detected=detected,controller_inferred=bool(inferred))
allrows=[]; summaries=[]
for cond in ["passive_natural","law_drift","random_external","adaptive_controller"]:
 for i in range(N):
  r,s=sim(15000+i,cond); allrows+=r; summaries.append(s)
cols=["seed","condition","t","x1","x2","x3","y1","y2","y3","a1","a2","a3"]
ts=pd.DataFrame(allrows,columns=cols); sm=pd.DataFrame(summaries)
ts.to_csv(O/"timeseries.csv",index=False); sm.to_csv(O/"replications.csv",index=False)
agg=sm.groupby("condition").agg(runs=("seed","count"),anomaly_rate=("anomaly_detected","mean"),
 inference_rate=("controller_inferred","mean"),mean_probe_score=("mean_probe_score","mean"),
 mean_positive_probes=("positive_probe_responses","mean")).reset_index()
agg.to_csv(O/"summary.csv",index=False)
report={"experiment":"Genesis-4.2 Active Probe of Unknown Feedback",
"design":{"runs_per_condition":N,"cycles":T,"randomized_probe_cycles":PROBES},
"controller":"Condition-blind state-feedback controller compensates 85% of any abrupt local negative deviation from its one-step ecological forecast; it is not given probe times or region labels.",
"observer":"Knows its own randomized intervention magnitude and region, compares observed change with the no-controller forecast; no condition labels or access to controller actions.",
"decision_rule":"Infer feedback controller if at least two of three probes show compensation >2 resource units.",
"results":agg.to_dict(orient="records"),
"limitations":["The controller is still a designed feedback rule, not an emergent conscious agent.",
"Observer's inference statistic is pre-specified and knows its own probe size.",
"Success indicates detectability of a state-responsive external process under this setup, not proof of consciousness, divinity, or our universe's origin."]}
(O/"report.json").write_text(json.dumps(report,indent=2))
print(agg.to_string(index=False))
