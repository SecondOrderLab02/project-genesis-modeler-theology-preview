
import numpy as np, pandas as pd, json, os, math
from dataclasses import dataclass

def run(seed, timing, T=900, N0=120):
    rng=np.random.default_rng(seed)
    # A closed monetary system: 600 units are split identically in both arms.
    # 60 units are transferred from households to the cooperative at t=0.
    n=N0
    cash=np.full(n, 4.5, dtype=float)  # 540
    firm_cash=60.0
    energy=np.full(n, 1.0, dtype=float)
    age=np.zeros(n, dtype=int)
    skill=np.clip(rng.normal(1.0,0.12,n),0.7,1.3)
    food=np.full(n, 0.45, dtype=float) # household initial food, separately accounted
    firm_food=70.0
    price=1.0
    hist=[]
    money0=600.0
    total_births=total_deaths=starve_deaths=0
    total_food_sold=total_food_need=total_food_consumed=0.0
    total_wages=0.0
    for t in range(T):
        # Aging and mortality
        age += 1
        # External occupation constraint retained from v10; not an emergent labor market.
        perm=rng.permutation(n)
        farmers=np.zeros(n,dtype=bool); farmers[perm[:max(1,int(round(.38*n)))]]=True
        # Wages from prior retained cash at start (prepay) vs current revenue at end (postpay)
        wage_paid=0.0
        if timing=="prepay" and n:
            budget=min(firm_cash, 0.055*n)
            if budget>0:
                # wages paid equally to all active workers, no money creation
                pay=budget/n
                cash += pay
                firm_cash -= budget
                wage_paid=budget
        # Production enters firm inventory; production scales with farmer count and skill.
        prod=float(np.sum(0.074*skill[farmers]))
        firm_food += prod
        # Perishable inventory: 1% spoilage per cycle
        spoil=firm_food*0.01
        firm_food-=spoil
        # Need and affordability
        need=np.full(n,0.022)
        total_need=float(need.sum())
        # Demand budget: households spend up to cash; food allocation at common price.
        desired=np.minimum(need, cash/max(price,1e-9))
        demand=float(desired.sum())
        sold=min(firm_food,demand)
        # Pro-rata allocation so no arbitrary first-come advantage.
        if demand>0:
            bought=desired*(sold/demand)
        else:
            bought=np.zeros(n)
        spend=float(bought.sum()*price)
        cash-=bought*price
        firm_cash+=spend
        firm_food-=sold
        # Postpay wages use current-cycle receipts, after food purchases.
        if timing=="postpay" and n:
            budget=min(firm_cash,0.055*n)
            if budget>0:
                pay=budget/n
                cash+=pay
                firm_cash-=budget
                wage_paid=budget
        total_wages+=wage_paid
        # Food consumption and energy balance. Unmet food creates energy deficit.
        coverage=np.divide(bought,need,out=np.zeros_like(bought),where=need>0)
        energy += 0.045*coverage - 0.028 - 0.018*(1-coverage)
        energy=np.clip(energy,0,1.35)
        # Natural mortality and starvation mortality
        starve_prob=np.clip((0.45-energy)*0.20,0,0.18)
        natural_prob=np.where(age>500,0.0015,0.00015)
        dead=(rng.random(n)<(starve_prob+natural_prob))
        starve_dead=(dead & (energy<0.45))
        total_deaths+=int(dead.sum()); starve_deaths+=int(starve_dead.sum())
        firm_cash += float(cash[dead].sum())  # deceased agents' cash remains inside the closed system
        keep=~dead
        cash=cash[keep]; energy=energy[keep]; age=age[keep]; skill=skill[keep]; food=food[keep]
        n=len(cash)
        # Density-sensitive reproduction; newborn receives no cash or food from nowhere.
        # Parent-funded birth: one parent pays 0.25 cash; child starts with 0.25 cash.
        births=0
        if n>1:
            density=max(0.0,1.0-n/260.0)
            p_birth=0.0028*density*np.clip((energy-0.55)/0.35,0,1)
            candidates=np.where((age>35)&(age<420)&(energy>0.65)&(cash>=0.5))[0]
            for parent in candidates:
                if rng.random()<float(p_birth[parent]):
                    cash[parent]-=0.25
                    cash=np.append(cash,0.25)
                    energy=np.append(energy,0.9)
                    age=np.append(age,0)
                    skill=np.append(skill,float(np.clip(rng.normal(1.0,0.12),0.7,1.3)))
                    food=np.append(food,0.0)
                    births+=1
            n=len(cash)
        total_births+=births
        # Price adapts slowly to inventory pressure, bounded.
        target=0.022*max(n,1)
        ratio=(prod+max(firm_food,0.0))/(target+1e-9)
        price=float(np.clip(price*(1+0.025*(1-ratio)),0.25,2.5))
        money_total=float(cash.sum()+firm_cash)
        hist.append((t,n,prod,sold,total_need,coverage.mean() if len(coverage) else 0,
                     price,firm_cash,firm_food,wage_paid,float(cash.sum()),money_total,
                     int(dead.sum()),births, float(energy.mean()) if n else 0))
        if n==0: break
    cols=["tick","population","food_produced","food_sold","food_need","food_coverage",
          "price","firm_cash","firm_food_inventory","wages_paid","household_cash",
          "money_total","deaths","births","mean_energy"]
    df=pd.DataFrame(hist,columns=cols)
    return df, {"seed":seed,"timing":timing,"ticks":len(df),"survived_900":len(df)==T and int(df.population.iloc[-1])>0,
                "final_population":int(df.population.iloc[-1]) if len(df) else 0,
                "peak_population":int(df.population.max()) if len(df) else 0,
                "births":total_births,"deaths":total_deaths,"starvation_deaths":starve_deaths,
                "mean_food_coverage":float(df.food_coverage.mean()) if len(df) else 0,
                "mean_wage_paid":float(df.wages_paid.mean()) if len(df) else 0,
                "max_money_error":float((df.money_total-money0).abs().max()) if len(df) else 0,
                "final_firm_cash":float(df.firm_cash.iloc[-1]) if len(df) else 0,
                "final_inventory":float(df.firm_food_inventory.iloc[-1]) if len(df) else 0}

all_rows=[]; primary={}
for timing in ["prepay","postpay"]:
    for seed in range(1000,1020):
        df, summary=run(seed,timing)
        all_rows.append(summary)
        if seed==1000:
            primary[timing]=df
rep=pd.DataFrame(all_rows)
rep.to_csv(os.path.join(os.path.dirname(__file__),"replications.csv"),index=False)
for k,df in primary.items():
    df.to_csv(os.path.join(os.path.dirname(__file__),f"primary_{k}.csv"),index=False)
summary={}
for timing,g in rep.groupby("timing"):
    summary[timing]={
        "survival_count":int(g.survived_900.sum()),
        "survival_rate":float(g.survived_900.mean()),
        "median_final_population":float(g.final_population.median()),
        "median_peak_population":float(g.peak_population.median()),
        "median_food_coverage":float(g.mean_food_coverage.median()),
        "median_starvation_deaths":float(g.starvation_deaths.median()),
        "median_money_error":float(g.max_money_error.median()),
        "median_ticks":float(g.ticks.median())
    }
report={"experiment":"Genesis-3.2 Economy v11","design":"20 seeds per wage timing; identical initial 600 money supply (540 households, 60 cooperative), production/consumption rules; prepay wages at tick start from retained firm cash vs postpay wages after current sales; 900-tick horizon.",
        "assumptions":["38% farmer share is externally imposed, not emergent.","Food output is 0.074 per farmer-skill unit; household need is 0.022 per person per tick.","Food inventory spoils by 1% per tick.","Wages are equal per capita and capped by available cooperative cash; no borrowing or money creation.","Birth cash is transferred from parent; no cash is created.","This is a stylized cooperative market prototype, not a free-market or human-level model."],
        "results":summary,"replication_rows":len(rep)}
with open(os.path.join(os.path.dirname(__file__),"report.json"),"w") as f: json.dump(report,f,indent=2)
print(json.dumps(report,indent=2))
