
import numpy as np,pandas as pd,json
from pathlib import Path
O=Path(__file__).parent
N=150; T=260; THRESH=48.0
def sim(seed,cond):
 rng=np.random.default_rng(seed)
 cap=np.array([100.,95.,105.]); regen=np.array([.043,.041,.045])
 x=np.array([66.,63.,68.]); base_ext=np.array([1.15,1.12,1.18])
 # one region undergoes gradual additional extraction; location and start vary by seed
 stressed=int(rng.integers(0,3)); start=int(rng.integers(95,125))
 rows=[]
 for t in range(T):
  season=1+.06*np.sin(2*np.pi*t/40)
  natural=regen*season*x*(1-x/cap)-base_ext
  # internally observable but not externally announced slow pressure
  extra=np.zeros(3)
  if t>=start: extra[stressed]=0.22
  x=x+natural-extra
  forecast=x+regen*season*x*(1-x/cap)-base_ext-extra
  action=np.zeros(3)
  if cond=="predictive_modeler":
   # forecasts two cycles ahead and acts before the threshold is crossed
   forecast2=x.copy()
   for _ in range(2):
    forecast2 += regen*season*forecast2*(1-forecast2/cap)-base_ext-extra
   action=np.minimum(4.0,np.maximum(0,THRESH+1.5-forecast2))
   x+=action
  elif cond=="reactive_controller":
   # only acts once current stock is already below threshold
   action=np.minimum(4.0,np.maximum(0,THRESH-x))
   x+=action
  elif cond=="random_controller":
   if t in [130,170,210]:
    action[rng.integers(0,3)]=rng.uniform(1,4)
    x+=action
  x=np.clip(x,0,cap*1.1)
  y=x+rng.normal(0,.65,3)
  rows.append({"seed":seed,"condition":cond,"t":t,"stressed_region":stressed,
   "x1":x[0],"x2":x[1],"x3":x[2],"y1":y[0],"y2":y[1],"y3":y[2],
   "a1":action[0],"a2":action[1],"a3":action[2],"pressure_start":start})
 d=pd.DataFrame(rows)
 # Observer fits/uses known ecological law and estimates two-step crossing risk from noisy state.
 # Count actions inferred from positive deviations above baseline in the stressed region.
 # Preemptive signature: positive unexplained support while current observed stock is still > THRESH.
 vals=d[d.t>=start].copy()
 r=stressed
 # Calculate observed one-step change and expected no-controller change.
 y=vals[["y1","y2","y3"]].values
 ts=vals.t.values
 resid=[]
 for j,t in enumerate(ts):
  if t==0: continue
  prev=d.loc[d.t==t-1,["y1","y2","y3"]].values[0]
  s=1+.06*np.sin(2*np.pi*t/40)
  expected=prev[r]+regen[r]*s*prev[r]*(1-prev[r]/cap[r])-base_ext[r]-.22
  residual=y[j,r]-expected
  # predictive signature if unexplained positive support occurs before crossing
  if y[j,r]>THRESH+2.5 and residual>1.3:
   resid.append((t,float(residual)))
 preemptive=len(resid)
 # Require multiple preemptive support events, not just one.
 inferred=preemptive>=4
 return d,{"seed":seed,"condition":cond,"stressed_region":r,"pressure_start":start,
  "preemptive_support_events":preemptive,"controller_inferred":bool(inferred),
  "total_external_action":float(d[["a1","a2","a3"]].sum().sum()),
  "min_stressed_stock":float(d[f"x{r+1}"].min())}
all_d=[]; all_s=[]
for c in ["natural","random_controller","reactive_controller","predictive_modeler"]:
 for i in range(N):
  d,s=sim(31000+i,c); all_d.append(d); all_s.append(s)
ts=pd.concat(all_d,ignore_index=True); sm=pd.DataFrame(all_s)
ts.to_csv(O/"timeseries.csv",index=False); sm.to_csv(O/"replications.csv",index=False)
agg=sm.groupby("condition").agg(runs=("seed","count"),
 inference_rate=("controller_inferred","mean"),
 mean_preemptive_events=("preemptive_support_events","mean"),
 mean_external_action=("total_external_action","mean"),
 mean_min_stock=("min_stressed_stock","mean")).reset_index()
agg.to_csv(O/"summary.csv",index=False)
report={"experiment":"Genesis-4.3 Predictive Modeler vs Reactive Controller",
"design":{"runs_per_condition":N,"cycles":T,"threshold":THRESH},
"conditions":{"natural":"No external intervention","random_controller":"Random additions at fixed cycles",
"reactive_controller":"Acts only after current stock falls below threshold",
"predictive_modeler":"Forecasts two cycles ahead and acts before predicted threshold crossing"},
"observer":"Uses noisy observations and known ecological transition law; detects unexplained positive support while stock is still above threshold.",
"decision_rule":"Infer predictive controller after at least four pre-threshold support events.",
"results":agg.to_dict(orient="records"),
"limitations":["The predictive and reactive controllers are hand-coded policies.",
"Observer has knowledge of the ecological law and threshold, and its residual test is pre-specified.",
"Positive support is evidence of an external intervention under this model, not proof of consciousness or divinity."]}
(O/"report.json").write_text(json.dumps(report,indent=2))
print(agg.to_string(index=False))
