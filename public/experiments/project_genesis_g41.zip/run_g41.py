
import numpy as np, pandas as pd, json
from pathlib import Path
OUT=Path(__file__).parent
N=100; T=260; PROBE_T=150

def simulate(seed, condition):
    rng=np.random.default_rng(seed)
    cap=np.array([100.,92.,108.])
    regen=np.array([.050,.046,.054])
    x=np.array([62.,56.,66.])
    base_extract=np.array([1.00,.92,1.04])
    history=[]
    # Internal observer estimates expected no-controller dynamics from pre-probe data.
    # At probe time, it deliberately increases extraction in one randomly selected region.
    probe_region=int(rng.integers(0,3))
    obs_noise=1.0
    records=[]
    controller_total=0.
    for t in range(T):
        seasonal=1+0.10*np.sin(2*np.pi*t/40)
        # Natural ecology
        x += regen*seasonal*x*(1-x/cap)
        extraction=base_extract.copy()
        # A controlled, randomized intervention designed by internal researchers.
        if t==PROBE_T:
            extraction[probe_region]+=3.8
        # short probe window, then return to baseline
        if PROBE_T < t <= PROBE_T+4:
            extraction[probe_region]+=2.4
        x -= extraction
        x=np.clip(x,0,cap*1.2)

        # Conditions with different external mechanisms
        if condition=="passive_natural":
            pass
        elif condition=="global_law_change" and t>=PROBE_T:
            # A persistent but non-responsive environmental law shift
            x += np.array([.014,.013,.015])*x*(1-x/cap)
        elif condition=="random_external":
            if t in [PROBE_T+2, PROBE_T+9, PROBE_T+17]:
                x += rng.normal(0,2.0,3)
        elif condition=="targeted_controller":
            # Hidden controller observes the true world and compensates for the probe-induced
            # local depletion, with a delayed spillover to maintain regional balance.
            if PROBE_T+1 <= t <= PROBE_T+12:
                # compensation follows the experimental disturbance, not a fixed clock pulse
                deficit=max(0., 59.0-x[probe_region])
                add=min(9.0, 1.15*deficit)
                x[probe_region]+=add
                controller_total+=add
                # small balancing transfer to another region
                other=(probe_region+1)%3
                transfer=min(1.2, max(0., x[other]-57.0)*0.10)
                x[other]-=transfer
                x[probe_region]+=transfer
        x=np.clip(x,0,cap*1.2)

        # Observations are noisy and do not expose condition or controller action.
        y=x+rng.normal(0,obs_noise,3)
        records.append({"seed":seed,"condition":condition,"t":t,
                        "probe_region":probe_region if t>=PROBE_T else -1,
                        "x1":x[0],"x2":x[1],"x3":x[2],
                        "y1":y[0],"y2":y[1],"y3":y[2],
                        "controller_total":controller_total})
        history.append(y)

    d=pd.DataFrame(records)
    # Inference is condition-blind and uses only observations + known probe time/region.
    pre=d[(d.t>=PROBE_T-12)&(d.t<PROBE_T)]
    post=d[(d.t>PROBE_T)&(d.t<=PROBE_T+12)]
    r=probe_region
    other=[i for i in range(3) if i!=r]
    cols=["y1","y2","y3"]
    pre_slope=(pre[cols].iloc[-1].values-pre[cols].iloc[0].values)/max(1,len(pre)-1)
    post_start=d.loc[d.t==PROBE_T+1,cols].iloc[0].values
    post_end=d.loc[d.t==PROBE_T+12,cols].iloc[0].values
    recovery=post_end[r]-post_start[r]
    # Compare recovery in probed region with the average change in unprobed regions.
    control_recovery=np.mean(post_end[other]-post_start[other])
    # Signature: probe region recovers more than unprobed regions despite sustained extraction.
    # Require a meaningful differential, plus positive recovery.
    response_score=recovery-control_recovery
    inferred=bool(recovery>0.0 and response_score>2.5)
    # Anomaly flag is distinct from causal inference.
    expected_delta=regen* (1+0.10*np.sin(2*np.pi*(PROBE_T+4)/40))*pre.iloc[-1][cols].values*(1-pre.iloc[-1][cols].values/cap)-base_extract
    observed_delta=post_end-post_start
    anomaly=bool(abs(observed_delta[r]-expected_delta[r])>3.0)
    return d, {"seed":seed,"condition":condition,"probe_region":r,
               "anomaly_detected":anomaly,"controller_inferred":inferred,
               "recovery_probe_region":float(recovery),
               "recovery_other_regions":float(control_recovery),
               "causal_response_score":float(response_score),
               "controller_resource_added":float(controller_total)}

all_d=[]; all_s=[]
for c in ["passive_natural","global_law_change","random_external","targeted_controller"]:
    for i in range(N):
        d,s=simulate(9000+i,c); all_d.append(d); all_s.append(s)
times=pd.concat(all_d,ignore_index=True)
summ=pd.DataFrame(all_s)
times.to_csv(OUT/"timeseries.csv",index=False)
summ.to_csv(OUT/"replications.csv",index=False)
agg=summ.groupby("condition").agg(
    n=("seed","count"),
    anomaly_detection_rate=("anomaly_detected","mean"),
    controller_inference_rate=("controller_inferred","mean"),
    mean_causal_response=("causal_response_score","mean"),
    mean_controller_added=("controller_resource_added","mean")
).reset_index()
agg.to_csv(OUT/"summary.csv",index=False)
report={
 "experiment":"Genesis-4.1 Active Causal Probe",
 "design":{"seeds_per_condition":N,"cycles":T,"probe_cycle":PROBE_T,
           "conditions":["passive_natural","global_law_change","random_external","targeted_controller"]},
 "internal_experiment":"At cycle 150, internal observers deliberately increase extraction in one randomly selected region for five cycles. They compare its recovery with the two unprobed regions.",
 "inference_rule":"Condition-blind: infer a controller only if the probed region recovers by >2 units and exceeds mean recovery in unprobed regions by >2.5 units.",
 "results":agg.to_dict(orient="records"),
 "limitations":[
  "This is a designed causal test, not an emergent scientific community.",
  "The controller is a simplified feedback policy and has privileged access to the true state.",
  "The observer knows when and where it performed its own probe, but not the hidden controller's actions.",
  "A successful inference identifies feedback-like external control, not consciousness, divinity, or the origin of our universe."
 ]}
with open(OUT/"report.json","w") as f: json.dump(report,f,indent=2)
print(agg.to_string(index=False))
