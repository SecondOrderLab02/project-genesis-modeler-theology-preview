
import numpy as np, pandas as pd, json, os

def run(seed, T=900, N0=120):
    rng=np.random.default_rng(seed)
    n=N0
    cash=np.full(n,5.0)  # 600 total money, no firm account in this version
    energy=np.full(n,1.0)
    age=np.zeros(n,dtype=int)
    skill_f=np.clip(rng.normal(1.0,.18,n),.55,1.45)
    skill_c=np.clip(rng.normal(1.0,.18,n),.55,1.45)
    # Three ecological zones with finite soil/fertility and seasonal rainfall
    soil=np.array([0.95,0.72,0.48],float)
    biomass=np.array([38.0,30.0,22.0],float)
    regen=np.array([0.10,0.075,0.05],float)
    # household food stores, initial stock is a transfer from initial ecosystem stock
    food=np.full(n,0.12)
    price=1.0
    hist=[]
    births_total=deaths_total=starve_total=0
    money0=float(cash.sum())
    estate_pool=0.0
    for t in range(T):
        age+=1
        season=1.0+0.22*np.sin(2*np.pi*t/90.0)
        rainfall=np.clip(season+rng.normal(0,.12),.55,1.45)
        # Ecological regeneration: biomass approaches soil-limited carrying capacity.
        carrying=soil*55.0*rainfall
        biomass += regen*rainfall*(carrying-biomass)
        biomass=np.maximum(biomass,0)
        # Each agent estimates returns from three occupations. Farming has ecological
        # dependence and stochastic yield; crafts/services earn only if there is demand.
        # Choice is autonomous but myopic: highest expected monetary return with a food-security premium.
        # Farmers harvest from zones proportionally; extraction cannot exceed biomass.
        exp_f=0.0
        if n:
            exp_f=price*0.34*np.mean(skill_f)*np.mean(soil)*rainfall
        exp_c=0.28*np.mean(skill_c)*max(price,0.3)
        # Existing cash and low energy increase preference for food-producing work.
        farm_score=exp_f + np.maximum(0,0.75-energy)*0.45
        craft_score=exp_c
        noise=rng.normal(0,.12,n)
        farmers=(farm_score+noise >= craft_score)
        # If no one farms, ecological food production is zero; no imposed minimum share.
        nf=int(farmers.sum())
        # Farm output draws down standing biomass; total harvest capped by available biomass.
        potential=np.zeros(n)
        potential[farmers]=0.34*skill_f[farmers]*rainfall
        total_potential=float(potential.sum())
        harvest=min(total_potential,float(biomass.sum())*0.035)
        if total_potential>0:
            produced=potential*(harvest/total_potential)
        else:
            produced=np.zeros(n)
        # distribute harvest among producers, then producers offer food for sale
        food_supply=float(produced.sum())
        biomass-=harvest*np.array([0.45,0.35,0.20])
        biomass=np.maximum(biomass,0)
        # Crafts/services produce a non-food good; buyers purchase only if they have surplus cash.
        craft_output=float(np.sum(0.22*skill_c[~farmers]))
        # Demand for food; agents spend a bounded fraction of available cash.
        need=np.full(n,0.022)
        # poor agents prioritise food; all money can be spent up to need
        desired=np.minimum(need, cash/max(price,1e-9))
        demand=float(desired.sum())
        # decentralized market: sellers are farmers; proportional rationing among buyers
        sold=min(food_supply,demand)
        bought=desired*(sold/demand) if demand>0 else np.zeros(n)
        spend=float(bought.sum()*price)
        cash-=bought*price
        # Food sales revenue distributed only to farmers in proportion to output
        if nf and food_supply>0:
            cash[farmers]+=spend*(produced[farmers]/food_supply)
        # Food is consumed; any unbought food is lost at 2% spoilage and rest carried by farmers
        food+=bought
        consumed=np.minimum(food,need)
        food-=consumed
        # craft/service income comes from a small exogenous demand pool only if food market is covered.
        # This is a deliberately limited local service market; it cannot create money.
        craft_idx=np.where(~farmers)[0]
        buyer_idx=np.where(farmers)[0]
        service_budget=min(float(cash[buyer_idx].sum())*0.015, 0.012*max(n,1)) if len(buyer_idx) else 0.0
        if len(craft_idx) and len(buyer_idx) and service_budget>0:
            buyer_weights=cash[buyer_idx]/max(float(cash[buyer_idx].sum()),1e-12)
            payments=service_budget*buyer_weights
            cash[buyer_idx]-=payments
            shares=skill_c[craft_idx]/skill_c[craft_idx].sum()
            cash[craft_idx]+=service_budget*shares
        energy += 0.048*(consumed/need) - 0.030 - 0.018*(1-consumed/need)
        energy=np.clip(energy,0,1.35)
        # Mortality and inheritance: dead agents' money passes to a communal estate account,
        # tracked separately so money remains conserved; estate is redistributed to newborns only.
        dead_prob=np.clip((0.48-energy)*0.18,0,0.16)+np.where(age>520,0.001,0.00012)
        dead=rng.random(n)<dead_prob
        starve=(dead & (energy<0.48))
        deaths_total+=int(dead.sum()); starve_total+=int(starve.sum())
        estate=float(cash[dead].sum())
        estate_pool += estate
        cash=cash[~dead]; energy=energy[~dead]; age=age[~dead]
        skill_f=skill_f[~dead]; skill_c=skill_c[~dead]; food=food[~dead]
        n=len(cash)
        births=0
        if n>1:
            density=max(0,1-n/250)
            fertile=np.where((age>35)&(age<420)&(energy>.68)&(cash>.3))[0]
            p=.0032*density*np.clip((energy[ fertile ]-.55)/.4,0,1)
            for j,idx in enumerate(fertile):
                if rng.random()<p[j]:
                    # parent transfers 0.15 cash to newborn; no new money
                    cash[idx]-=.15
                    cash=np.append(cash,.15)
                    energy=np.append(energy,.9)
                    age=np.append(age,0)
                    skill_f=np.append(skill_f,float(np.clip(rng.normal(1,.18),.55,1.45)))
                    skill_c=np.append(skill_c,float(np.clip(rng.normal(1,.18),.55,1.45)))
                    food=np.append(food,0.0)
                    births+=1
            n=len(cash)
        births_total+=births
        # Death estate is held in a transparent communal pool; it is not redistributed in this version.
        # We include it in total money accounting.
        # A small proportion of the estate is returned to local circulation next tick.
        estate_return=estate_pool*.01
        if n and estate_return>0:
            cash += estate_return/n
            estate_pool -= estate_return
        # Price adjusts to scarcity, not a fixed floor only.
        coverage=float(consumed.sum()/max(need.sum(),1e-9))
        price=float(np.clip(price*(1+0.035*(1-coverage)),.2,3.0))
        money_total=float(cash.sum()+estate_pool)
        hist.append((t,n,nf/n if n else 0,food_supply,demand,sold,coverage,price,
                     float(biomass.sum()),float(soil.mean()),float(energy.mean()) if n else 0,
                     births,int(dead.sum()),int(starve.sum()),float(cash.sum()),estate_pool,money_total,
                     craft_output))
        if n==0: break
    cols=["tick","population","farmer_share","food_produced","food_demand","food_sold",
          "food_coverage","food_price","biomass","mean_soil","mean_energy","births",
          "deaths","starvation_deaths","household_cash","estate_cash","money_total","craft_output"]
    df=pd.DataFrame(hist,columns=cols)
    return df, {"seed":seed,"ticks":len(df),"survived_900":len(df)==T and int(df.population.iloc[-1])>0,
        "final_population":int(df.population.iloc[-1]) if len(df) else 0,
        "peak_population":int(df.population.max()) if len(df) else 0,
        "mean_farmer_share":float(df.farmer_share.mean()) if len(df) else 0,
        "mean_food_coverage":float(df.food_coverage.mean()) if len(df) else 0,
        "median_food_coverage":float(df.food_coverage.median()) if len(df) else 0,
        "starvation_deaths":starve_total,"births":births_total,"deaths":deaths_total,
        "min_biomass":float(df.biomass.min()) if len(df) else 0,
        "max_money_error":float((df.money_total-600).abs().max()) if len(df) else 0}

rows=[]; primary=None
for seed in range(2000,2020):
    df,s=run(seed); rows.append(s)
    if seed==2000: primary=df
rep=pd.DataFrame(rows)
rep.to_csv(os.path.join(os.path.dirname(__file__),"replications.csv"),index=False)
primary.to_csv(os.path.join(os.path.dirname(__file__),"primary_history.csv"),index=False)
summary={"experiment":"Genesis-3.2 Economy v12","design":"20 seeds, 900 ticks; endogenous myopic occupation choice between farming and crafts; finite regenerative biomass across three zones; decentralized food market; fixed initial money stock 600; no minimum farmer quota.",
"assumptions":["Two occupation options only; choices are myopic expected-return comparisons, not human-like planning.","Food production is bounded by standing ecological biomass and harvest rate; soil and rainfall constrain regeneration.","Craft/service demand is represented by a small transfer from existing household cash, not an external money source.","No credit, state, taxation, family institutions, technology, or interregional trade.","Initial farmer/crafter skills are heterogeneous; the farmer share is endogenous each tick.","This is a toy ecological economy, not a model of humanity or a complete civilization."],
"results":{"survival_count":int(rep.survived_900.sum()),"survival_rate":float(rep.survived_900.mean()),
"median_final_population":float(rep.final_population.median()),"min_final_population":int(rep.final_population.min()),
"max_final_population":int(rep.final_population.max()),"median_peak_population":float(rep.peak_population.median()),
"median_farmer_share":float(rep.mean_farmer_share.median()),"median_food_coverage":float(rep.mean_food_coverage.median()),
"median_starvation_deaths":float(rep.starvation_deaths.median()),"median_min_biomass":float(rep.min_biomass.median()),
"median_money_error":float(rep.max_money_error.median()),"median_ticks":float(rep.ticks.median())}}
with open(os.path.join(os.path.dirname(__file__),"report.json"),"w") as f: json.dump({"summary":summary,"replications":rows},f,indent=2)
print(json.dumps(summary,indent=2))
