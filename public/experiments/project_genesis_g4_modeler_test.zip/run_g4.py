
import numpy as np, pandas as pd, json
from pathlib import Path
OUT=Path(__file__).parent
SEEDS=100; T=240; IT=120
def run(seed, condition):
    rng=np.random.default_rng(seed)
    x=np.array([50.,42.,35.]); regen=np.array([.055,.047,.060]); cap=np.array([100.,90.,105.])
    A=24
    histories=[[] for _ in range(A)]
    evidence=np.zeros(A,dtype=int); detected=np.zeros(A,dtype=bool); hypothesis=np.zeros(A,dtype=bool)
    pulse_signs=[[] for _ in range(A)]
    rows=[]
    for t in range(T):
        seasonal=1+.12*np.sin(2*np.pi*t/40)
        x += regen*seasonal*x*(1-x/cap)-np.array([1.10,.95,1.00])
        x=np.clip(x,0,cap*1.3)
        action="none"
        if condition=="local" and t==IT:
            x[0]+=18; action="local_injection"
        elif condition=="law" and t>=IT:
            x += np.array([.020,.017,.022])*x*(1-x/cap); action="law_shift"
        elif condition=="modeler" and t in [IT,IT+12,IT+24]:
            pulse=np.array([8.,7.,9.]) if t!=IT+12 else np.array([-5.,-4.,-6.])
            x=np.clip(x+pulse,0,cap*1.3); action="coordinated_pulse"
        for a in range(A):
            y=x+rng.normal(0,1.2,3)
            if condition=="noise" and t==IT: y[0]+=rng.choice([-1,1])*22
            if histories[a]:
                prev=np.array(histories[a][-1])
                pred=prev+regen*seasonal*prev*(1-prev/cap)-np.array([1.10,.95,1.00])
                resid=y-pred
                z=resid/1.8
                multi=(np.abs(z)>3.5).sum()>=2
                if multi:
                    evidence[a]+=1; detected[a]=True
                # Controller inference from repeated, synchronized sign reversals.
                if (np.abs(z)>2.8).all() and (np.all(z>0) or np.all(z<0)):
                    pulse_signs[a].append(1 if np.mean(z)>0 else -1)
                    pulse_signs[a]=pulse_signs[a][-3:]
                    if pulse_signs[a]==[1,-1,1]:
                        hypothesis[a]=True
            histories[a].append(y.tolist())
        rows.append({"seed":seed,"condition":condition,"t":t,"x1":x[0],"x2":x[1],"x3":x[2],
                     "action":action,"detected_rate":detected.mean(),"hypothesis_rate":hypothesis.mean()})
    return rows,{"seed":seed,"condition":condition,"any_detection":bool(detected.any()),
      "observer_detection_rate":float(detected.mean()),"observer_modeler_hypothesis_rate":float(hypothesis.mean()),
      "final_resources":float(x.sum()),"intervention_events":sum(r["action"]!="none" for r in rows)}
allr=[]; alls=[]
for c in ["natural","noise","local","law","modeler"]:
 for s in range(SEEDS):
  r,a=run(s+1000,c); allr.extend(r); alls.append(a)
df=pd.DataFrame(allr); sm=pd.DataFrame(alls)
df.to_csv(OUT/"timeseries.csv",index=False); sm.to_csv(OUT/"replications.csv",index=False)
agg=sm.groupby("condition").agg(seeds=("seed","count"),any_detection_rate=("any_detection","mean"),
 mean_observer_detection=("observer_detection_rate","mean"),
 mean_modeler_hypothesis=("observer_modeler_hypothesis_rate","mean"),
 mean_final_resources=("final_resources","mean"),mean_intervention_events=("intervention_events","mean")).reset_index()
agg.to_csv(OUT/"summary.csv",index=False)
report={"experiment":"Genesis-4.0 Minimal Modeler Inference Test (condition-blind observer rule)",
 "design":{"seeds_per_condition":SEEDS,"cycles":T,"intervention_cycle":IT},
 "observer_rule":"Detect synchronized anomalies from noisy observations; infer controller only after observing three synchronized pulse-signs +,-,+. The observer code does not read the condition label.",
 "results":agg.to_dict(orient="records"),
 "limitations":["Observer rule is hand-designed, not independently evolved.",
 "The intervention signature is deliberately structured; results show detectability only under these assumptions.",
 "Compact resource ecology, not a civilization.",
 "Does not establish that the real universe has an external modeler."]}
with open(OUT/"report.json","w") as f: json.dump(report,f,indent=2)
print(agg.to_string(index=False))
