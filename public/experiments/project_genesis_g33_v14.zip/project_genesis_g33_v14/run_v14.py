
import numpy as np, pandas as pd, json, os

def run(seed, treatment, T=900, N0=120):
    rng=np.random.default_rng(seed)
    # Three regions with different initial fertility and resource endowments.
    pop=np.array([50,40,30],dtype=int)
    cash=np.array([250.,200.,150.])
    energy=np.ones(3)
    soil=np.array([.95,.72,.48],float)
    biomass=np.array([38.,30.,22.],float)
    storage=np.zeros(3)
    price=np.ones(3)
    estate=0.0
    hist=[]
    deaths_total=starve_total=births_total=trade_total=0
    money0=float(cash.sum())
    # Treatments: baseline / storage / storage+trade / storage+trade+governance
    storage_on=treatment in ("storage","trade","governance")
    trade_on=treatment in ("trade","governance")
    gov_on=treatment=="governance"
    for t in range(T):
        season=1+.22*np.sin(2*np.pi*t/90)
        rain=np.clip(season+rng.normal(0,.12,3),.55,1.45)
        if 300<=t<400:
            rain*=.48
        if t>=400:
            soil *= .9985
        carrying=soil*55*rain
        biomass += np.array([.10,.075,.05])*rain*(carrying-biomass)
        biomass=np.maximum(biomass,0)
        # Local occupation share adapts to local expected return, without a fixed quota.
        farm_share=np.clip(.33 + .30*(energy-.75) + .18*(soil-.7),.12,.72)
        # Small stochastic regional productivity variation.
        farm_share=np.clip(farm_share+rng.normal(0,.025,3),.08,.8)
        # harvest constrained by local biomass; region-specific output
        potential=pop*farm_share*.34*rain
        harvest=np.minimum(potential, biomass*.035)
        biomass-=harvest
        # local food production and demand
        need=pop*.022
        local_supply=harvest+storage
        storage=np.zeros(3)
        # Governance can reserve a share of current output when supply exceeds local need.
        if storage_on:
            reserve_rate=.12 if not gov_on else .22
            reserve=np.minimum(harvest*reserve_rate, np.maximum(0,local_supply-need*.82))
            local_supply-=reserve
            storage+=reserve
        # Interregional trade: surplus regions ship to deficits. Trade cost is physical loss.
        trade_volume=0.0
        if trade_on:
            surplus=np.maximum(local_supply-need,0)
            deficit=np.maximum(need-local_supply,0)
            for dest in range(3):
                if deficit[dest]<=0: continue
                for src in np.argsort(-surplus):
                    if src==dest or surplus[src]<=0: continue
                    shipment=min(deficit[dest]/.92,surplus[src])
                    delivered=shipment*.92
                    local_supply[src]-=shipment
                    local_supply[dest]+=delivered
                    surplus[src]-=shipment
                    deficit[dest]-=delivered
                    trade_volume+=shipment
                    if deficit[dest]<=1e-9: break
        # Governance also coordinates emergency release from storage and reallocates a limited
        # share of regional cash to food-poor regions; cash transfers are internal.
        if gov_on and storage.sum()>0:
            deficits=np.maximum(need-local_supply,0)
            for dest in range(3):
                if deficits[dest]<=0: continue
                donors=np.argsort(-storage)
                for src in donors:
                    if src==dest or storage[src]<=0: continue
                    shipment=min(deficits[dest],storage[src])
                    storage[src]-=shipment
                    local_supply[dest]+=shipment
                    deficits[dest]-=shipment
                    if deficits[dest]<=1e-9: break
        # Regional affordability limits food purchased; transfers do not create money.
        affordable=np.minimum(need, cash/np.maximum(price,1e-6))
        bought=np.minimum(local_supply,affordable)
        spend=bought*price
        cash-=spend
        # Food revenue goes to local farming households as wage/profit income.
        cash += spend
        # Food consumption coverage and energy.
        coverage=np.divide(bought,need,out=np.ones(3),where=need>0)
        energy += .048*coverage-.030-.018*(1-coverage)
        energy=np.clip(energy,0,1.35)
        # Small region-to-region cash settlement for traded food.
        if trade_on:
            # sellers are paid by destination; net transfer approximated at regional level
            # Keep total money constant; price-weighted settlement moves cash from high cash to low cash regions.
            for _ in range(2):
                rich=int(np.argmax(cash)); poor=int(np.argmin(cash))
                transfer=min(.002*cash[rich], max(0,.15*(cash[rich]-cash[poor])))
                cash[rich]-=transfer; cash[poor]+=transfer
        # Deaths and births by region; deaths do not erase money.
        mortality=np.clip((.48-energy)*.18,0,.16)+.00012
        deaths=rng.binomial(pop,mortality)
        starvation=np.where(coverage<.75,deaths,0)
        deaths_total+=int(deaths.sum()); starve_total+=int(starvation.sum())
        # Deceased residents' money remains in regional estate, later redistributed locally.
        for r in range(3):
            if pop[r]>0:
                estate += cash[r]*(deaths[r]/pop[r])
                cash[r] *= (1-deaths[r]/pop[r])
        pop-=deaths
        # Fertility depends on energy and density; births funded by existing communal cash.
        births=np.zeros(3,dtype=int)
        for r in range(3):
            if pop[r]>0:
                density=max(0,1-pop[r]/100)
                p=.0025*density*np.clip((energy[r]-.55)/.4,0,1)
                births[r]=rng.binomial(pop[r],p)
                # Aggregate regional model: newborns have no separately minted wallet.
                # Population growth does not alter the regional cash ledger.
                pop[r]+=births[r]
        births_total+=int(births.sum())
        # Estate pool slowly returns to regional circulation.
        release=estate*.01
        if pop.sum()>0:
            cash += release*(pop/max(pop.sum(),1))
            estate-=release
        # Storage spoilage; 1% each cycle.
        storage*=.99
        # Price reacts to local coverage; price increase cannot create food.
        price=np.clip(price*(1+.035*(1-coverage)),.2,3)
        money_total=float(cash.sum()+estate)
        hist.append((t,int(pop.sum()),*pop.tolist(),*farm_share.tolist(),*coverage.tolist(),
                     *biomass.tolist(),*storage.tolist(),*cash.tolist(),float(estate),
                     float(money_total),float(trade_volume),float(energy.mean())))
        if pop.sum()==0: break
    cols=["tick","population","pop_r1","pop_r2","pop_r3","farm_r1","farm_r2","farm_r3",
          "coverage_r1","coverage_r2","coverage_r3","biomass_r1","biomass_r2","biomass_r3",
          "storage_r1","storage_r2","storage_r3","cash_r1","cash_r2","cash_r3","estate",
          "money_total","trade_volume","mean_energy"]
    df=pd.DataFrame(hist,columns=cols)
    return df,{"seed":seed,"treatment":treatment,"ticks":len(df),
      "survived_900":len(df)==T and int(df.population.iloc[-1])>0,
      "final_population":int(df.population.iloc[-1]) if len(df) else 0,
      "peak_population":int(df.population.max()) if len(df) else 0,
      "starvation_deaths":starve_total,"births":births_total,"deaths":deaths_total,
      "mean_coverage":float(df[["coverage_r1","coverage_r2","coverage_r3"]].mean().mean()) if len(df) else 0,
      "mean_trade_volume":float(df.trade_volume.mean()) if len(df) else 0,
      "min_total_biomass":float(df[["biomass_r1","biomass_r2","biomass_r3"]].sum(axis=1).min()) if len(df) else 0,
      "max_money_error":float((df.money_total-600).abs().max()) if len(df) else 0,
      "final_storage":float(df[["storage_r1","storage_r2","storage_r3"]].sum().iloc[-1]) if len(df) else 0}

rows=[]; primary={}
for tr in ["baseline","storage","trade","governance"]:
    for seed in range(4000,4020):
        df,s=run(seed,tr); rows.append(s)
        if seed==4000: primary[tr]=df
rep=pd.DataFrame(rows)
rep.to_csv(os.path.join(os.path.dirname(__file__),"replications.csv"),index=False)
for tr,df in primary.items(): df.to_csv(os.path.join(os.path.dirname(__file__),f"primary_{tr}.csv"),index=False)
summ={}
for tr,g in rep.groupby("treatment"):
    summ[tr]={"survival":int(g.survived_900.sum()),"median_ticks":float(g.ticks.median()),
      "median_final_population":float(g.final_population.median()),
      "median_peak_population":float(g.peak_population.median()),
      "median_starvation_deaths":float(g.starvation_deaths.median()),
      "median_food_coverage":float(g.mean_coverage.median()),
      "median_trade_volume":float(g.mean_trade_volume.median()),
      "median_money_error":float(g.max_money_error.median())}
report={"experiment":"Project Genesis G3.3 v14","design":"80 runs: 4 institutional treatments x 20 paired seeds; identical 3-region ecology and severe shock (rainfall -52% at ticks 300-399; soil degrades 0.15% per tick from tick 400); 900 tick horizon.",
"treatments":{"baseline":"No storage, no trade, no coordinated governance.","storage":"Local food reserves; reserve 12% of harvest when supply permits.","trade":"Local reserves plus interregional food trade with 8% transport loss.","governance":"Reserves (22%), interregional trade, and emergency reserve transfers across regions."},
"assumptions":["Three regions have different fertility and starting biomass.","Occupation shares respond to local energy and soil but are not individual agent decisions.","This is a regional population-level mechanism test, not an agent-level institution model.","Regional food market accounting and cash ledger are stylized; no credit, technology, migration, taxes, or politics.","Money is conserved in cash plus estate; food is physically conserved apart from explicit transport loss and storage spoilage."],
"results":summ,"rows":rows}
with open(os.path.join(os.path.dirname(__file__),"report.json"),"w") as f: json.dump(report,f,indent=2)
print(json.dumps(summ,indent=2))
