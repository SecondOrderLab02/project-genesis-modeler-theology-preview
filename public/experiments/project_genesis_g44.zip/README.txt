Project Genesis G4.4 results package. See G4.4_report.md, CSV outputs, audit JSON, and PNG plot.
