
import numpy as np, pandas as pd, json, os

def run(seed, scenario="control", T=900, N0=120):
    rng=np.random.default_rng(seed)
    n=N0
    cash=np.full(n,5.0)
    energy=np.full(n,1.0)
    age=np.zeros(n,dtype=int)
    skill_f=np.clip(rng.normal(1.0,.18,n),.55,1.45)
    skill_c=np.clip(rng.normal(1.0,.18,n),.55,1.45)
    soil=np.array([.95,.72,.48],float)
    biomass=np.array([38.,30.,22.])
    regen=np.array([.10,.075,.05])
    price=1.0
    money0=float(cash.sum())
    estate_pool=0.0
    hist=[]
    births_total=deaths_total=starve_total=0
    for t in range(T):
        age+=1
        season=1+.22*np.sin(2*np.pi*t/90)
        rainfall=np.clip(season+rng.normal(0,.12),.55,1.45)
        rain_shock=1.0
        if scenario in ("moderate","severe") and 300<=t<400:
            rain_shock=.72 if scenario=="moderate" else .48
        rainfall*=rain_shock
        if scenario in ("moderate","severe") and t>=400:
            soil *= (0.9995 if scenario=="moderate" else 0.9985)
        # Soil damage is persistent and gradual after the shock point.
        carrying=soil*55*rainfall
        biomass += regen*rainfall*(carrying-biomass)
        biomass=np.maximum(biomass,0)
        exp_f=price*.34*np.mean(skill_f)*np.mean(soil)*rainfall if n else 0
        exp_c=.28*np.mean(skill_c)*max(price,.3) if n else 0
        farm_score=exp_f+np.maximum(0,.75-energy)*.45
        craft_score=exp_c
        noise=rng.normal(0,.12,n)
        farmers=(farm_score+noise>=craft_score)
        nf=int(farmers.sum())
        potential=np.zeros(n)
        potential[farmers]=.34*skill_f[farmers]*rainfall
        total_p=float(potential.sum())
        harvest=min(total_p,float(biomass.sum())*.035)
        produced=potential*(harvest/total_p) if total_p>0 else np.zeros(n)
        food_supply=float(produced.sum())
        biomass-=harvest*np.array([.45,.35,.20])
        biomass=np.maximum(biomass,0)
        craft_output=float(np.sum(.22*skill_c[~farmers]))
        need=np.full(n,.022)
        desired=np.minimum(need,cash/max(price,1e-9))
        demand=float(desired.sum())
        sold=min(food_supply,demand)
        bought=desired*(sold/demand) if demand>0 else np.zeros(n)
        spend=float(bought.sum()*price)
        cash-=bought*price
        if nf and food_supply>0:
            cash[farmers]+=spend*(produced[farmers]/food_supply)
        consumed=bought
        coverage=float(consumed.sum()/max(need.sum(),1e-9))
        craft_idx=np.where(~farmers)[0]
        buyer_idx=np.where(farmers)[0]
        service_budget=min(float(cash[buyer_idx].sum())*.015,.012*max(n,1)) if len(buyer_idx) else 0
        if len(craft_idx) and len(buyer_idx) and service_budget>0:
            w=cash[buyer_idx]/max(float(cash[buyer_idx].sum()),1e-12)
            cash[buyer_idx]-=service_budget*w
            cash[craft_idx]+=service_budget*skill_c[craft_idx]/skill_c[craft_idx].sum()
        energy += .048*(consumed/need)-.030-.018*(1-consumed/need)
        energy=np.clip(energy,0,1.35)
        dead_prob=np.clip((.48-energy)*.18,0,.16)+np.where(age>520,.001,.00012)
        dead=rng.random(n)<dead_prob
        starve=dead&(energy<.48)
        deaths_total+=int(dead.sum()); starve_total+=int(starve.sum())
        estate_pool+=float(cash[dead].sum())
        cash=cash[~dead]; energy=energy[~dead]; age=age[~dead]
        skill_f=skill_f[~dead]; skill_c=skill_c[~dead]
        n=len(cash)
        births=0
        if n>1:
            density=max(0,1-n/250)
            fertile=np.where((age>35)&(age<420)&(energy>.68)&(cash>.3))[0]
            probs=.0032*density*np.clip((energy[fertile]-.55)/.4,0,1)
            for j,idx in enumerate(fertile):
                if rng.random()<probs[j]:
                    cash[idx]-=.15
                    cash=np.append(cash,.15); energy=np.append(energy,.9); age=np.append(age,0)
                    skill_f=np.append(skill_f,float(np.clip(rng.normal(1,.18),.55,1.45)))
                    skill_c=np.append(skill_c,float(np.clip(rng.normal(1,.18),.55,1.45)))
                    births+=1
            n=len(cash)
        births_total+=births
        estate_return=estate_pool*.01
        if n and estate_return>0:
            cash+=estate_return/n
            estate_pool-=estate_return
        price=float(np.clip(price*(1+.035*(1-coverage)),.2,3.0))
        money_total=float(cash.sum()+estate_pool)
        hist.append((t,n,nf/n if n else 0,food_supply,demand,sold,coverage,price,
                     float(biomass.sum()),float(soil.mean()),float(energy.mean()) if n else 0,
                     births,int(dead.sum()),int(starve.sum()),float(cash.sum()),estate_pool,money_total,
                     rainfall,craft_output))
        if n==0: break
    cols=["tick","population","farmer_share","food_produced","food_demand","food_sold","food_coverage",
          "food_price","biomass","mean_soil","mean_energy","births","deaths","starvation_deaths",
          "household_cash","estate_cash","money_total","rainfall","craft_output"]
    df=pd.DataFrame(hist,columns=cols)
    # Recovery: population at tick 600 relative to pre-shock population at 299.
    pre=float(df.loc[df.tick==299,"population"].iloc[0]) if (df.tick==299).any() else float(df.population.iloc[0])
    at600=float(df.loc[df.tick==600,"population"].iloc[0]) if (df.tick==600).any() else float(df.population.iloc[-1])
    return df, {"seed":seed,"scenario":scenario,"ticks":len(df),"survived_900":len(df)==T and int(df.population.iloc[-1])>0,
        "final_population":int(df.population.iloc[-1]) if len(df) else 0,
        "peak_population":int(df.population.max()) if len(df) else 0,
        "population_pre_shock":pre,"population_tick600":at600,
        "population_change_to_600":(at600/pre-1) if pre else None,
        "mean_farmer_share":float(df.farmer_share.mean()) if len(df) else 0,
        "mean_food_coverage":float(df.food_coverage.mean()) if len(df) else 0,
        "min_food_coverage":float(df.food_coverage.min()) if len(df) else 0,
        "starvation_deaths":starve_total,"births":births_total,"deaths":deaths_total,
        "min_biomass":float(df.biomass.min()) if len(df) else 0,
        "max_money_error":float((df.money_total-600).abs().max()) if len(df) else 0}

rows=[]; primary={}
for scenario in ["control","moderate","severe"]:
    for seed in range(3000,3020):
        df,s=run(seed,scenario); rows.append(s)
        if seed==3000: primary[scenario]=df
rep=pd.DataFrame(rows)
rep.to_csv(os.path.join(os.path.dirname(__file__),"replications.csv"),index=False)
for k,v in primary.items(): v.to_csv(os.path.join(os.path.dirname(__file__),f"primary_{k}.csv"),index=False)
summary={}
for sc,g in rep.groupby("scenario"):
    summary[sc]={k:float(g[k].median()) for k in ["ticks","final_population","peak_population","population_pre_shock","population_tick600","population_change_to_600","mean_farmer_share","mean_food_coverage","min_food_coverage","starvation_deaths","min_biomass","max_money_error"]}
    summary[sc]["survival_count"]=int(g.survived_900.sum())
report={"experiment":"Genesis-3.2 Economy v13","design":"Three scenarios, 20 seeds each, 900 ticks. Control has seasonal rainfall only. Moderate: rainfall multiplier 0.72 during ticks 300-399, then soil fertility decays 0.05% per tick from tick 400. Severe: rainfall multiplier 0.48 during ticks 300-399, then soil fertility decays 0.15% per tick. All other rules and seed sets matched.",
"assumptions":["This is a stylized two-occupation ecological economy, not a human-level civilization.","Occupation choice is myopic and uses expected returns plus a food-security premium.","Harvest is bounded by standing biomass; biomass regenerates according to soil and rainfall.","No government, credit, technology, trade between regions, or deliberate adaptation policy.","Money is conserved: market/service payments are transfers; deceased agents' money remains in an estate pool; newborn cash is transferred by a parent."],
"results":summary,"replications":rows}
with open(os.path.join(os.path.dirname(__file__),"report.json"),"w") as f: json.dump(report,f,indent=2)
print(json.dumps({"summary":summary},indent=2))
